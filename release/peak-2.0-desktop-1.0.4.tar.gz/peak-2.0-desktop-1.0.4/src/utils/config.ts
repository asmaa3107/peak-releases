const config = {
  app_name: 'Peak',
  title: 'Peak time tracking',
  description: 'Peak for time tracking and productivity',
  locale: 'en',
  peakAPI: 'https://peak-2-api.herokuapp.com/api',
  peakFrontend:'https://app.peaktime.app/',

};

export default config;
