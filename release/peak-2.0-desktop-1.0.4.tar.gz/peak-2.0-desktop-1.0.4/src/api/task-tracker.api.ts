// import type { InitiateTrackingSessionResponse } from '../types/task-tracking.type';
// // import { axiosErrorHandler } from '../utils/handle-errors';
import { InitiateTrackingSessionResponse } from 'types/task-tracking.type';
import { apiClientWithToken } from './apiClient';
// import { UnexpectedError } from './errors';

export const initiateTrackingSessionRequest = async (
  taskId: string,
  companyId: string
) => {
  try {
    const result =
      await apiClientWithToken.get<InitiateTrackingSessionResponse>(
        `/task-tracker/company/${companyId}/task/${taskId}`
      );
    return result.data;
  } catch (err) {
    console.log(err);
    //throw new Error('handle later');
  }
};

export const refreshTrackingSessionRequest = async (trackingId: string) => {
  try {
    const result = await apiClientWithToken.get(`/task-tracker/${trackingId}`);
    return result.data;
  } catch (err) {
    console.log(err);
    //todo: stopped for now - couse app not closing
    // throw new Error('handle later');
  }
};

export const endTrackingSessionRequest = async (trackingId: string) => {
  try {
    const result = await apiClientWithToken.get(
      `/task-tracker/${trackingId}/end`
    );
    return result.data;
  } catch (err) {
    console.log(err);
   // throw new Error('handle later');
  }
};
