/* eslint-disable import/prefer-default-export */
import { GetUserInfoResponse, SignInFormData, SignInResponseData } from 'types';
import { apiClient, apiClientWithToken } from './apiClient';

export const login = async (data: SignInFormData) => {
  const response = await apiClient.post<SignInResponseData>(
    '/auth/login',
    data
  );
  return response.data;
};

export const getLoggedInUserInfo = async () => {
  const response = await apiClientWithToken.get<GetUserInfoResponse>(
    '/auth/user-info'
  );
  return response.data;
};
