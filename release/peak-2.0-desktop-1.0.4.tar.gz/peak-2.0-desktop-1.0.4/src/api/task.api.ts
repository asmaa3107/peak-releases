/* eslint-disable import/prefer-default-export */
import {
  CreateTaskFormData,
  CreateTaskResponse,
  DeleteTaskResponse,
  ListTasksResponse,
  UpdateTaskFormData,
  UpdateTaskResponse,
} from 'types/task.types';
import { apiClient, apiClientWithToken } from './apiClient';

export const listUserTasks = async (companyId: string) => {
  try {
    const result = await apiClientWithToken.get<ListTasksResponse>(
      `/task/company/${companyId}/me`
    );
    return result.data;
  } catch (err) {
    console.log('error');
    console.log(err);
    throw Error('');
  }
};

export const createTask = async (
  data: CreateTaskFormData,
  companyId?: string
) => {
  try {
    const result = await apiClientWithToken.post<CreateTaskResponse>(
      `/task/company/${companyId}`,
      data
    );
    return result.data;
  } catch (err) {
    console.log('error');
    console.log(err);
    throw Error('');
  }
};

export const deleteTaskRequest = async (taskId?: string) => {
  try {
    const result = await apiClientWithToken.delete<DeleteTaskResponse>(
      `/task/${taskId}`
    );
    return result.data;
  } catch (err) {
    console.log('error');
    console.log(err);
    throw Error('');
  }
};

export const updateTaskRequest = async (
  data: UpdateTaskFormData,
  taskId?: string
) => {
  try {
    const result = await apiClientWithToken.put<UpdateTaskResponse>(
      `/task/${taskId}`,
      data
    );
    return result.data;
  } catch (err) {
    console.log('error');
    console.log(err);
    throw Error('');
  }
};
