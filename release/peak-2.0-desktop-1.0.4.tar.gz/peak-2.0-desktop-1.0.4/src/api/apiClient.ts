import axios from 'axios';

import { getElectronStore } from 'renderer/utils/electron-utils';
import config from '../utils/config';

const apiClient = axios.create({ baseURL: config.peakAPI });

const apiClientWithToken = axios.create({ baseURL: config.peakAPI });

apiClientWithToken.interceptors.request.use(
  (reqConfig) => {
    const accessToken = getElectronStore<string>('access_token');

    if (accessToken) {
      reqConfig.headers.Authorization = `Bearer ${accessToken}`;
    }

    return reqConfig;
  },
  (error) => {
    return Promise.reject(error);
  }
);

export { apiClientWithToken, apiClient };
