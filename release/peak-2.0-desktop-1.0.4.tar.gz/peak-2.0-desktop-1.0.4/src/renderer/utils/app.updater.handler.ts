/* eslint-disable promise/always-return */
/* eslint-disable promise/catch-or-return */
/* eslint-disable no-underscore-dangle */
/* eslint-disable import/prefer-default-export */
// eslint-disable-next-line import/prefer-default-export

import { endTrackingSessionRequest } from 'api';
import { emitAppUpdateAvaliable, emitAppUpdateCanceled, emitAppUpdateDownloaded, emitAppUpdateNotavalible } from './electron-utils';

export const handleAppUpdateEvents = () => {
  emitAppUpdateAvaliable();
  emitAppUpdateCanceled();
  emitAppUpdateDownloaded();
  emitAppUpdateNotavalible();
};
