/* eslint-disable import/prefer-default-export */

import { Channels } from 'types';

// utils
export const openExternalLink = (url: string) => {
  window.electron.ipcRenderer.sendMessage(Channels.OPEN_EXTERNAL_LINK, [url]);
};

// electron store
export const setElectronStore = <T>(key: string, value: T) => {
  window.electron.store.set(key, value);
};

export const getElectronStore = <T>(key: string): T => {
  const value = window.electron.store.get(key);
  return value;
};

// time tracking events
export const emitTimeTrackingStartedEvent = (idleThresholdSeconds: number) => {
  window.electron.ipcRenderer.sendMessage(
    Channels.TIME_TRACKING_STARTED,
    idleThresholdSeconds
  );
};

export const emitTimeTrackingStoppedEvent = () => {
  window.electron.ipcRenderer.sendMessage(Channels.TIME_TRACKING_STOPPED);
};

export const listenShowIdleWarningModal = (func: () => void) => {
  window.electron.ipcRenderer.on(Channels.SHOW_IDLE_WARNING_MODAL, func);
};

export const listenShowIdleModal = (func: () => void) => {
  window.electron.ipcRenderer.on(Channels.IDLE_DETECTED, func);
};

// application events
export const emitAppCloseEvent = () => {
  window.electron.ipcRenderer.sendMessage(Channels.APP_QUIT);
};

//Check App Updates EVENTS
// application events
export const emitAppUpdateDownloaded= () => {
  console.log('******************');
  console.log('*emitAppUpdateDownloaded');
  window.electron.ipcRenderer.sendMessage(Channels.UPDATE_DOWNLOADED);
};

export const emitAppUpdateCanceled= () => {
  console.log('******************');
  console.log('*emitAppUpdateCanceled');
  window.electron.ipcRenderer.sendMessage(Channels.UPDATE_CANCELLED);
};

export const emitAppUpdateAvaliable= () => {
  console.log('******************');
  console.log('*emitAppUpdateAvaliable');
  window.electron.ipcRenderer.sendMessage(Channels.UPDATE_AVAILABLE);
};

export const emitAppUpdateNotavalible= () => {
  console.log('******************');
  console.log('*emitAppUpdateNotavalible');
  window.electron.ipcRenderer.sendMessage(Channels.UPDATE_NOT_AVAILABLE);
};
