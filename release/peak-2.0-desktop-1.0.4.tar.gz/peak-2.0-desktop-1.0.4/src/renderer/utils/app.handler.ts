/* eslint-disable promise/always-return */
/* eslint-disable promise/catch-or-return */
/* eslint-disable no-underscore-dangle */
/* eslint-disable import/prefer-default-export */
// eslint-disable-next-line import/prefer-default-export

import { endTrackingSessionRequest } from 'api';
import { emitAppCloseEvent } from './electron-utils';

export const handleAppOnClose = (trackingId: string) => {
  window._saved = false;
  window.onbeforeunload = async (e) => {
    if (!window._saved) {
      try{
        await endTrackingSessionRequest(trackingId).then((res) => {
          if (res) {
            // success? quit the app
            window._saved = true;
            emitAppCloseEvent();
            window.onbeforeunload = null;
          }
        });
      }
      catch(err) {
          console.log(err);
      }
    }
    e.returnValue = false;
  };
};
