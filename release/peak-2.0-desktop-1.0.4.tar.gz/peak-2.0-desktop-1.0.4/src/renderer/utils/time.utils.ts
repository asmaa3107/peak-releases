/* eslint-disable import/no-extraneous-dependencies */

/**
 * Convert seconds to hh:mm:ss
 * @param {number} seconds
 */
export const formatToHoursMinutesSeconds = (seconds: number) => {
  return new Date(seconds * 1000).toISOString().substring(11, 19);
};

export const formatToHoursMinutes = (seconds: number) => {
  const sec = seconds / (60 * 60);
  const hours = Math.floor(sec);
  const min = ((sec % 1) * 60).toFixed(0);
  return ` ${hours} h ${min} m`;
};
