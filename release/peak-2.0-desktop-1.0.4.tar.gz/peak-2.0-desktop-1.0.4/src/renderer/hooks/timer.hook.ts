/* eslint-disable import/prefer-default-export */
/* eslint-disable react-hooks/exhaustive-deps */
import { useEffect } from 'react';

import { refreshTrackingSessionRequest } from 'api';
import {
  listenShowIdleModal,
  listenShowIdleWarningModal,
} from 'renderer/utils/electron-utils';
import { incrementTaskTotalWorkedSecondsToday } from 'renderer/redux/features/task.slice';
import {
  incrementCurrentTaskTodayWorkedSeconds,
  incrementTotalWorkedSecondsToday,
  setIsTrackingState,
} from 'renderer/redux/features/timeTracker.slice';
import {
  setShowIdleModal,
  setShowIdleWarningModal,
} from 'renderer/redux/features/modal.slice';
import { handleAppOnClose } from 'renderer/utils/app.handler';
import { useAppDispatch, useAppSelector } from './store.hook';

export const useTimerRefreshPoll = () => {
  const taskTrackingState = useAppSelector((state) => state.timeTrackerState);
  useEffect(() => {
    let refreshInterval: any;
    if (taskTrackingState.isTracking) {
      refreshInterval = setInterval(() => {
        refreshTrackingSessionRequest(taskTrackingState.trackingId);
      }, 60000);
    }
    return () => clearInterval(refreshInterval);
  }, [taskTrackingState.isTracking]);
};

export const useTimerCounterInterval = () => {
  const dispatch = useAppDispatch();
  const timeTrackingState = useAppSelector((state) => state.timeTrackerState);
  useEffect(() => {
    let timeCounterInterval: any;
    if (timeTrackingState.isTracking) {
      timeCounterInterval = setInterval(() => {
        dispatch(
          incrementTaskTotalWorkedSecondsToday({
            taskId: timeTrackingState.taskId,
          })
        );
        dispatch(incrementCurrentTaskTodayWorkedSeconds());
        dispatch(incrementTotalWorkedSecondsToday());

        listenShowIdleWarningModal(async () => {
          dispatch(setShowIdleWarningModal(true));
        });

       

        handleAppOnClose(timeTrackingState.trackingId);
      }, 1000);
    }
    return () => clearInterval(timeCounterInterval);
  }, [timeTrackingState]);
};
