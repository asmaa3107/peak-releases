import { getLoggedInUserInfo } from 'api';
import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { getElectronStore } from 'renderer/utils/electron-utils';
import {
  setSelectedCompany,
  setUser,
} from 'renderer/redux/features/user.slice';
import { useAppDispatch } from './store.hook';

const useAuthGuard = () => {
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  useEffect(() => {
    const token = getElectronStore<string>('access_token');
    if (!token) {
      navigate('/login');
    }
  });
  getLoggedInUserInfo()
    .then((response) => {
      dispatch(setUser(response));
      return dispatch(setSelectedCompany(response.companies[0]));
    })
    .catch((err) => {
      console.log(err);
      navigate('/login');
    });
};

export default useAuthGuard;
