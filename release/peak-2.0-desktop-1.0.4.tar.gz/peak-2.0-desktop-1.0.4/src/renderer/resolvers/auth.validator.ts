/* eslint-disable import/prefer-default-export */
import * as Yup from 'yup';

import { ERROR_MESSAGES } from './constants';

export const SignInFormValidator = Yup.object().shape({
  username: Yup.string().email().required(ERROR_MESSAGES.required),
  password: Yup.string().required(ERROR_MESSAGES.required),
});
