import { Button, Modal } from 'flowbite-react';
import React from 'react';
import { TfiAlert } from 'react-icons/tfi';

interface DeleteAlertProps {
  handleDelete: (taskId: string) => void;
  setAlert: React.Dispatch<React.SetStateAction<boolean>>;
  alert: boolean;
  setDeleteId: React.Dispatch<React.SetStateAction<string>>;
  deleteId: string;
}

function DeleteTaskModalAlert(props: DeleteAlertProps) {
  const { alert, setAlert, handleDelete, deleteId, setDeleteId } = props;
  return (
    <Modal show={alert} size="md" popup={true} onClose={() => setAlert(false)} className='pt-28 h-full'>
      <Modal.Header />
      <Modal.Body>
        <TfiAlert className="mx-auto mb-4 h-14 w-14 text-gray-400 dark:text-gray-200" />
        <div className="text-center">
          <h3 className="mb-5 text-lg font-normal text-black dark:text-gray-400">
            Are you sure you want to delete task?
            <p className="text-sm leading-relaxed text-gray-500 dark:text-gray-400">
              Deleting this task will delete time within the task!
            </p>
          </h3>

          <div className="flex justify-center gap-4">
            <Button
              color="failure"
              onClick={() => {
                handleDelete(deleteId);
                setAlert(false);
              }}
            >
              Yes, I am sure
            </Button>
            <Button
              color="gray"
              onClick={() => {
                setAlert(false);
                setDeleteId('');
              }}
            >
              No, cancel
            </Button>
          </div>
        </div>
      </Modal.Body>
    </Modal>
  );
}

export default DeleteTaskModalAlert;
