/* eslint-disable consistent-return */
import { endTrackingSessionRequest, refreshTrackingSessionRequest } from 'api';
import { Button, Modal } from 'flowbite-react';
import { useEffect, useState } from 'react';

import { useAppDispatch, useAppSelector } from 'renderer/hooks/store.hook';
import { setShowIdleModal, setShowIdleWarningModal } from 'renderer/redux/features/modal.slice';
import { setIsTrackingState } from 'renderer/redux/features/timeTracker.slice';
import { emitTimeTrackingStoppedEvent } from 'renderer/utils/electron-utils';

export default function IdleWarningModal() {
  const dispatch = useAppDispatch();
  const {
    timeTrackerState: { trackingId ,refreshAfterIdle },
    modalState,
  } = useAppSelector((state) => state);
  const [toIdleCounter, setToIdleCounter] = useState(10);
  const { showIdleWarningModal } = modalState;

  const handleStopTimeOnClick = async () => {
    try {
      const response = await endTrackingSessionRequest(trackingId);
      if (response) {
        dispatch(setIsTrackingState(false));
        dispatch(setShowIdleWarningModal(false));
        emitTimeTrackingStoppedEvent();
      }
    } catch (err) {
      console.log(err);
    }
  };

  const handleResumeOnClick = async () => {
    try {
      const response = await refreshTrackingSessionRequest(trackingId);
      if (response) {
        dispatch(setShowIdleWarningModal(false));
        refreshTrackingSessionRequest(trackingId);
      }
    } catch (err) {
      console.log(err);
    }
  };

  const handleIdle = () => {
    dispatch(setIsTrackingState(false));
    dispatch(setShowIdleWarningModal(false));
    dispatch(setShowIdleModal(true));
    handleStopTimeOnClick()
  }

  useEffect(() => {
    if (!showIdleWarningModal) {
      setToIdleCounter(10);
      return;
    }
    if(toIdleCounter < 1 ) {
      handleIdle();
      return;
    }
    const interval = setInterval(() => {
      setToIdleCounter((prev) => prev - 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [showIdleWarningModal, toIdleCounter]);

  return (
    <Modal show={showIdleWarningModal} className='pt-28 h-full'>
      <Modal.Header>Idle Warning</Modal.Header>
      <Modal.Body>
        <div className="space-y-6">
          <p className="text-base leading-relaxed text-gray-500 dark:text-gray-400">
            You have been Idle, Please take an action
          </p>
          <p className="text-base leading-relaxed text-gray-500 dark:text-gray-400">
            {toIdleCounter}
          </p>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button onClick={handleResumeOnClick}>Resume Tracker</Button>
        <Button color="gray" onClick={handleStopTimeOnClick}>
          Stop Tracker
        </Button>
      </Modal.Footer>
    </Modal>
  );
}
