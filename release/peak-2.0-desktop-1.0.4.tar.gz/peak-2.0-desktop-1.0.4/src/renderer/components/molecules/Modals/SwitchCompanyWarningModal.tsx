/* eslint-disable consistent-return */
import { endTrackingSessionRequest } from 'api';
import { Button, Modal } from 'flowbite-react';

import { useAppDispatch, useAppSelector } from 'renderer/hooks/store.hook';
import { setSwitchCompanyWarningModal } from 'renderer/redux/features/modal.slice';
import {
  resetTimeTrackerState,
  setIsTrackingState,
} from 'renderer/redux/features/timeTracker.slice';
import { setSelectedCompany } from 'renderer/redux/features/user.slice';
import { emitTimeTrackingStoppedEvent } from 'renderer/utils/electron-utils';

export default function SwitchCompanyWarningModal() {
  const dispatch = useAppDispatch();
  const {
    userState: { desiredSelectedCompany },
    timeTrackerState: { trackingId },
    modalState,
  } = useAppSelector((state) => state);
  const { showSwitchCompanyWarningModal: showSwitchCompanyModal } = modalState;

  const handleResumeTrackerOnClick = async () => {
    dispatch(setSwitchCompanyWarningModal(false));
  };

  const handleSwitchCompanyOnClick = async () => {
    try {
      const response = await endTrackingSessionRequest(trackingId);
      if (response) {
        dispatch(setIsTrackingState(false));
        dispatch(setSelectedCompany(desiredSelectedCompany!));
        dispatch(setSwitchCompanyWarningModal(false));
        dispatch(resetTimeTrackerState());
        emitTimeTrackingStoppedEvent();
      }
    } catch (err) {
      console.log(err);
    }
  };

  return (
    <Modal show={showSwitchCompanyModal} className='pt-28 h-full'>
      <Modal.Header>Idle Warning</Modal.Header>
      <Modal.Body>
        <div className="space-y-6">
          <p className="text-base leading-relaxed text-gray-500 dark:text-gray-400">
            Are You sure you want to switch Company?
          </p>
          <p className="text-base leading-relaxed text-gray-500 dark:text-gray-400">
            you are currently working on task
          </p>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button color="gray" onClick={handleSwitchCompanyOnClick}>
          Switch Company
        </Button>
        <Button onClick={handleResumeTrackerOnClick}>Resume Tracker</Button>
      </Modal.Footer>
    </Modal>
  );
}
