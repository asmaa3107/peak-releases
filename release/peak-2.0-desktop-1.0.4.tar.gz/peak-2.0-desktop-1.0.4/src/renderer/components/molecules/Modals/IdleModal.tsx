/* eslint-disable consistent-return */
import { initiateTrackingSessionRequest } from 'api';
import { Button, Modal } from 'flowbite-react';
import { useEffect, useState } from 'react';

import { useAppDispatch, useAppSelector } from 'renderer/hooks/store.hook';
import { setShowIdleModal } from 'renderer/redux/features/modal.slice';
import { setCurrentTaskTrackingState, setRefreshAfterIdle } from 'renderer/redux/features/timeTracker.slice';
import { emitTimeTrackingStartedEvent } from 'renderer/utils/electron-utils';
import { formatToHoursMinutesSeconds } from 'renderer/utils/time.utils';

export default function IdleModal() {
  const dispatch = useAppDispatch();
  const {
    timeTrackerState: {
      taskId,
      taskTitle,
      totalWorkedSecondsToday,
      idleTimeoutInSeconds,
      refreshAfterIdle
    },
    userState: { selectedCompany },
    modalState: { showIdleModal },
  } = useAppSelector((state) => state);
  const [IdleCounter, setIdleCounter] = useState(idleTimeoutInSeconds);

  const selectedCompanyId = selectedCompany?.companyId;

  const handleCancelButtonOnClick = async () => {
    try {
      setIdleCounter(0)
      dispatch(setShowIdleModal(false));
    } catch (err) {
      console.log(err);
    }
  };

  const handleBackToWorkOnClick = async () => {
    try {
      const taskTrackingSessionRes = await initiateTrackingSessionRequest(
        taskId,
        selectedCompanyId as string
      );
      if (taskTrackingSessionRes) {
        dispatch(
          setCurrentTaskTrackingState({
            currentTaskTodayWorkedSeconds:
              taskTrackingSessionRes.totalWorkedSecondsToday,
            idleTimeoutInSeconds: taskTrackingSessionRes.idleTimeout,
            isTracking: true,
            taskId: taskTrackingSessionRes.taskId,
            trackingId: taskTrackingSessionRes.trackingId,
            taskTitle,
            totalWorkedSecondsToday,
          })
        );
        setIdleCounter(0);
        dispatch(setShowIdleModal(false));
        dispatch(setRefreshAfterIdle(!refreshAfterIdle));

      }
      console.log('RESTART TIME TRACKING');
      emitTimeTrackingStartedEvent(taskTrackingSessionRes!.idleTimeout);
    } catch (err) {
      console.log(err);
    }

  };

  useEffect(() => {
    if (!showIdleModal) return;
    const interval = setInterval(() => {
      setIdleCounter((prev) => prev + 1);
    }, 1000);
    return () => clearInterval(interval);
  }, [showIdleModal]);

  return (
    <Modal show={showIdleModal} className='pt-28 h-full'>
      <Modal.Header>Idle</Modal.Header>
      <Modal.Body>
        <div className="space-y-6">
          <p className="text-base leading-relaxed text-gray-500 dark:text-gray-400">
            You have been Idle for
          </p>
          <p className="text-base leading-relaxed text-gray-500 dark:text-gray-400">
            {formatToHoursMinutesSeconds(IdleCounter)}
          </p>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button onClick={handleBackToWorkOnClick}>Back to Work</Button>
        <Button color="gray" onClick={handleCancelButtonOnClick}>
          Cancel
        </Button>
      </Modal.Footer>
    </Modal>
  );
}
