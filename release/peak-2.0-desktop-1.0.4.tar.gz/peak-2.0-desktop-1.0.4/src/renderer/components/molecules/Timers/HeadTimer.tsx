import StartTimerButton from 'renderer/components/atoms/TimerButtons/StartTimerButton';
import StopTimerButton from 'renderer/components/atoms/TimerButtons/StopTimerButton';
import { useAppSelector } from 'renderer/hooks/store.hook';
import { formatToHoursMinutes,formatToHoursMinutesSeconds } from 'renderer/utils/time.utils';

export default function HeadTimer() {
  const timeTrackerState = useAppSelector((state) => state.timeTrackerState);
  const username = useAppSelector((state)=>state.userState.user?.name);
  const taskTitle = timeTrackerState?.taskTitle;

  const trackerColorClass = timeTrackerState.isTracking
    ? 'bg-green text-white'
    : 'bg-gray-100 text-cyan-900';
  const isTaskSelected = timeTrackerState.taskId !== '';
  return (
    <>
      {isTaskSelected ? (
        <div
          className={`flex items-center justify-center fixed p-4 z-20 w-screen ${trackerColorClass}`}
        >
          <div className="flex-auto text-2xl font-bold truncate uppercase">
            <span>{taskTitle}</span>
          </div>
          <div className="ml-8 mr-8 text-2xl font-bold">
            <span>
              {formatToHoursMinutesSeconds(
                timeTrackerState.currentTaskTodayWorkedSeconds
              )}
            </span>
          </div>
          <div className="mt-2 mr-16">
            {!timeTrackerState.isTracking ? (
              <StartTimerButton
                taskId={timeTrackerState.taskId}
                taskTitle={timeTrackerState.taskTitle}
              />
            ) : (
              <StopTimerButton trackingId={timeTrackerState.trackingId} />
            )}
          </div>
        </div>
      ) : (
        <div className="p-8 bg-primary fixed w-full text-white uppercase font-bold z-20">Welcome, {(username)? username : ''}  </div>
      )}
      <div className="p-4 mt-20">
        Total worked time today:
        <b> {formatToHoursMinutes(timeTrackerState.totalWorkedSecondsToday)} </b>
      </div>
      {/* time worked today */}
    </>
  );
}
