/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-underscore-dangle */
/* eslint-disable consistent-return */
import { useEffect, useState } from 'react';

import StartTimerButton from 'renderer/components/atoms/TimerButtons/StartTimerButton';
import StopTimerButton from 'renderer/components/atoms/TimerButtons/StopTimerButton';
import { useAppSelector } from 'renderer/hooks/store.hook';
import { formatToHoursMinutesSeconds } from 'renderer/utils/time.utils';
import { Task, TaskStatus } from 'types/task.types';

type TimerButtonProps = {
  task: Task;
};

export default function Timer({ task }: TimerButtonProps) {
  const taskTrackerState = useAppSelector((state) => state.timeTrackerState);
  const [isTracking, setIsTracking] = useState<boolean>(false);

  useEffect(() => {
    setIsTracking(
      task._id === taskTrackerState.taskId && taskTrackerState.isTracking
    );
  }, [taskTrackerState.isTracking, taskTrackerState.taskId]);

  return (
    <>
      <p>{formatToHoursMinutesSeconds(task.totalWorkedSecondsToday)}</p>
      {task.status === TaskStatus.PLANNED ?
      <>
       {!isTracking ? (
        <StartTimerButton taskId={task._id} taskTitle={task.title} />
      ) : (
        <StopTimerButton trackingId={taskTrackerState.trackingId} />
      )}

      </>
     : null }

    </>
  );
}
