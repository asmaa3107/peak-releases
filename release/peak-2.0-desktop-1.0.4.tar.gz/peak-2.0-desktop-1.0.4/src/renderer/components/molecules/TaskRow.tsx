/* eslint-disable no-underscore-dangle */

import { Task, TaskStatus, UpdateTaskFormData } from 'types/task.types';
import Timer from './Timers/Timer';
import { FaEdit, FaFolderPlus, FaTrash } from 'react-icons/fa';
import { dispatch } from 'renderer/redux/store';
import { deleteTaskRequest, updateTaskRequest } from 'api/task.api';
import { useAppSelector } from 'renderer/hooks/store.hook';
import { deleteTask, editTask } from 'renderer/redux/features/task.slice';
import { Checkbox, TextInput } from 'flowbite-react';
import { useEffect, useState } from 'react';
import { endTrackingSessionRequest } from 'api';
import { resetHeaderTimeTrackerState, setIsTrackingState } from 'renderer/redux/features/timeTracker.slice';
import { emitTimeTrackingStoppedEvent } from 'renderer/utils/electron-utils';
import DeleteTaskModalAlert from './Modals/DeleteTaskModalAlert';

type TaskRowProp = {
  task: Task;
};

export default function TaskRow({ task }: TaskRowProp) {
  const [edit, setEdit] = useState(false);
  const [alert, setAlert] = useState(false);
  const [deleteId, setDeleteId] = useState<string>('');
  let {
    isTracking,
    taskId: trackingTaskId,
    trackingId,
  } = useAppSelector((state) => state.timeTrackerState);

  const handleDelete = async (taskId: string) => {
    try {
      const response = await deleteTaskRequest(taskId);
      if (response) {
        dispatch(deleteTask(response));
        setAlert(false);
        setDeleteId('');
      }
    } catch (err) {
      console.log(err);
    }
  };

  const handleEditTaskTitle = async (title: string, taskId: string) => {
    try {
      const response = await updateTaskRequest(
        {
          title: title,
          _id: taskId,
        },
        taskId
      );
      if (response) {
        dispatch(editTask(response));
      }
    } catch (err) {
      console.log(err);
    }
  };

  const handleStopButtonOnDoneStatus = async () => {
    try {
      const response = await endTrackingSessionRequest(trackingId);
      console.log('hi');
      if (response) dispatch(setIsTrackingState(false));
      emitTimeTrackingStoppedEvent();
    } catch (err) {
      console.log(err);
    }
  };
  const handleEditTaskStatus = async (status: TaskStatus, taskId: string) => {
    if (status === TaskStatus.DONE) {
      status = TaskStatus.PLANNED;
    } else {
        //show warning
        //stop task
        handleStopButtonOnDoneStatus();
        //empty global state (header title)
        dispatch(resetHeaderTimeTrackerState());
        //dispatch edit task
        status = TaskStatus.DONE;
    }
    try {
      const response = await updateTaskRequest(
        {
          status: status,
          _id: taskId,
        },
        taskId
      );
      if (response) {
        dispatch(editTask(response));
      }
    } catch (err) {
      console.log(err);
    }
  };

  const [showDeleteButton, setShowDeleteButton] = useState(true);
  useEffect(() => {
    const isCurrentTrackingTask = isTracking && trackingTaskId === task._id;
    setShowDeleteButton(isCurrentTrackingTask);
  }, [isTracking, trackingTaskId]);

  return (
    <div className="w-full">
      <div className="flow-root ">
        <DeleteTaskModalAlert
          handleDelete={handleDelete}
          alert={alert}
          setAlert={setAlert}
          setDeleteId={setDeleteId}
          deleteId={deleteId}
        />

        <ul className="w-full  divide-y divide-gray-200 dark:divide-gray-700">
          <li
            className={`w-full py-2 sm:py-2 ${
              showDeleteButton ? 'highlighted' : ''
            }`}
          >
            <div className="flex w-full  items-center space-x-4 px-4">
              <div className="min-w-0 flex-1">
                <div className="truncate text-base font-normal text-gray-900 dark:text-white flex items-center gap-2 ">
                  {!edit ? (
                    task.status === TaskStatus.PLANNED ? (
                      <>
                        <Checkbox
                          className="rounded-full"
                          onChange={() =>
                            handleEditTaskStatus(TaskStatus.PLANNED, task._id)
                          }
                        />
                        {task.title}
                      </>
                    ) : task.status === TaskStatus.DONE ? (
                      <>
                        <Checkbox
                          className="rounded-full"
                          onChange={() =>
                            handleEditTaskStatus(TaskStatus.DONE, task._id)
                          }
                          checked
                        />
                        <del>{task.title}</del>
                      </>
                    ) : null
                  ) : (
                    <TextInput
                      type="text"
                      defaultValue={task.title}
                      required={false}
                      onBlur={(e) => {
                        setEdit(false);
                        handleEditTaskTitle(e.target.value, task._id);
                      }}
                    />
                  )}
                </div>
              </div>
              <button>
                <FaEdit
                  fontSize={25}
                  color="#384D6C"
                  onClick={() => {
                    setEdit((prev) => !prev);
                  }}
                />
              </button>
              <div className="ml-20  flex items-center gap-5 text-base font-semibold text-gray-900 dark:text-white">
                <Timer task={task} />
              </div>
              <button
                disabled={showDeleteButton}
                onClick={() => {
                  setAlert(true);
                  setDeleteId(task._id);
                }}
              >
                <FaTrash
                  fontSize={25}
                  color={!showDeleteButton ? '#C66267' : '#fff'}
                />
              </button>
            </div>
          </li>
        </ul>
      </div>
    </div>
  );
}
