/* eslint-disable react/jsx-props-no-spreading */
import { Label, TextInput } from 'flowbite-react';

import type { InputFieldProps } from './EmailInputField';
import ErrorText from './ErrorText';

export default function PasswordInputField({
  labelText,
  register,
  errorMessage,
}: Omit<InputFieldProps, 'placeholder'>) {
  return (
    <div className="mb-2 block">
      <Label value={labelText} />
      <TextInput type="password" required {...register} />
      {errorMessage && <ErrorText errorMessage={errorMessage} />}
    </div>
  );
}
