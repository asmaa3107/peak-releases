/* eslint-disable react/jsx-props-no-spreading */
/* eslint-disable react/require-default-props */
import { Label, TextInput } from 'flowbite-react';
import type { UseFormRegisterReturn } from 'react-hook-form';

import ErrorText from './ErrorText';

export type InputFieldProps = {
  labelText: string;
  placeholder: string;
  register: UseFormRegisterReturn;
  errorMessage?: string;
};

export default function EmailInputField({
  labelText,
  placeholder,
  register,
  errorMessage,
}: InputFieldProps) {
  return (
    <div className="mb-2 block">
      <Label value={labelText} />
      <TextInput
        type="email"
        placeholder={placeholder}
        required
        {...register}
      />
      {errorMessage && <ErrorText errorMessage={errorMessage} />}
    </div>
  );
}
