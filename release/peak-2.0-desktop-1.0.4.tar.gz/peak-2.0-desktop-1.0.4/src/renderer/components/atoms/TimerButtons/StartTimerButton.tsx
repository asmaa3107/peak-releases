import { endTrackingSessionRequest, initiateTrackingSessionRequest } from 'api';
import React from 'react';
import { FaPlayCircle } from 'react-icons/fa';
import { useAppDispatch, useAppSelector } from 'renderer/hooks/store.hook';
import {
  setCurrentTaskTrackingState,
  setIsTrackingState,
  setRefreshAfterIdle,
} from 'renderer/redux/features/timeTracker.slice';
import {
  emitTimeTrackingStartedEvent,
  emitTimeTrackingStoppedEvent,
} from 'renderer/utils/electron-utils';

type StartTimerButtonProps = {
  taskId: string;
  taskTitle: string;
};

export default function StartTimerButton({
  taskId,
  taskTitle,
}: StartTimerButtonProps) {
  const dispatch = useAppDispatch();
  const {
    userState: { selectedCompany },
    timeTrackerState: {
      isTracking,
      trackingId: previousRunningTrackingId,
      totalWorkedSecondsToday,
      refreshAfterIdle
    },
  } = useAppSelector((state) => state);
  const handleStartButtonOnClick = async () => {
    try {
      if (isTracking) {
        const response = await endTrackingSessionRequest(
          previousRunningTrackingId
        );
        if (response) {
          dispatch(setIsTrackingState(false));
          emitTimeTrackingStoppedEvent();
        }
      }

      const taskTrackingSessionRes = await initiateTrackingSessionRequest(
        taskId,
        selectedCompany?.companyId as string
      );
      dispatch(setRefreshAfterIdle(!refreshAfterIdle));

      dispatch(
        setCurrentTaskTrackingState({
          currentTaskTodayWorkedSeconds:
            taskTrackingSessionRes!.totalWorkedSecondsToday,
          idleTimeoutInSeconds: taskTrackingSessionRes!.idleTimeout,
          isTracking: true,
          taskId: taskTrackingSessionRes!.taskId,
          trackingId: taskTrackingSessionRes!.trackingId,
          taskTitle,
          totalWorkedSecondsToday,
        })
      );
      // send idletimeout - 10 ( take action counter)
      emitTimeTrackingStartedEvent((taskTrackingSessionRes!.idleTimeout - 10));
    } catch (err) {
      console.log('error');
      console.log(err);
    }
  };
  return (
    <button
      type="button"
      onClick={async () => {
        await handleStartButtonOnClick();
      }}
    >
      <FaPlayCircle fontSize={35} color="#1D8163" />
    </button>
  );
}
