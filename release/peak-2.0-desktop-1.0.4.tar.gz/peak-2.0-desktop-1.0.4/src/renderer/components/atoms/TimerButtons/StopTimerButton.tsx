import { endTrackingSessionRequest } from 'api';
import { FaPauseCircle, FaStopCircle } from 'react-icons/fa';

import { setIsTrackingState } from 'renderer/redux/features/timeTracker.slice';
import { useAppDispatch } from 'renderer/hooks/store.hook';
import { emitTimeTrackingStoppedEvent } from 'renderer/utils/electron-utils';

type StopTimerButtonProps = {
  trackingId: string;
};

export default function StopTimerButton({ trackingId }: StopTimerButtonProps) {
  const dispatch = useAppDispatch();
  const handleStopButtonOnClick = async () => {
    try {
      const response = await endTrackingSessionRequest(trackingId);
      console.log('hi');
      if (response) dispatch(setIsTrackingState(false));
      emitTimeTrackingStoppedEvent();
    } catch (err) {
      console.log(err);
    }
  };
  return (
    <button type="button" onClick={handleStopButtonOnClick}>
      <FaStopCircle fontSize={35} color="#C66267" className='pouseButn'/>
    </button>
  );
}
