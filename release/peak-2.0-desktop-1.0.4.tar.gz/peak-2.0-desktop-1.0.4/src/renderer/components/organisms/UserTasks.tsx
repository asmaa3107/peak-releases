/* eslint-disable react-hooks/exhaustive-deps */
/* eslint-disable no-underscore-dangle */
import { createTask, listUserTasks } from 'api/task.api';
import React, { useEffect, useState } from 'react';
import { useAppDispatch, useAppSelector } from 'renderer/hooks/store.hook';
import { setRefreshAfterIdle, setTotalWorkedSecondsToday } from 'renderer/redux/features/timeTracker.slice';
import { addTask, setTasks, syncTasks } from 'renderer/redux/features/task.slice';
import TaskRow from '../molecules/TaskRow';
import { FormProvider, useForm } from 'react-hook-form';
import { CreateTaskFormData, Task, TaskStatus } from 'types/task.types';
import TextInputField from '../atoms/Inputs/TextInputField';
import { FaPlusCircle } from 'react-icons/fa';
import { handleAppUpdateEvents } from 'renderer/utils/app.updater.handler';
import { refreshTrackingSessionRequest } from 'api';

export default function UserTasks() {
  const dispatch = useAppDispatch();
  const {
    userState: { selectedCompany },
    tasksState: { tasks },

    timeTrackerState: {refreshAfterIdle ,trackingId}
  } = useAppSelector((state) => state);
  const [sync , setSync] = useState(false)

  const methods = useForm<CreateTaskFormData>({
    mode: 'onSubmit',
    defaultValues: {
      title: '',
    },
  });
  const { register, handleSubmit, setValue } = methods;
  useEffect(() => {
    if (selectedCompany?.companyId) {
      listUserTasks(selectedCompany.companyId)
        .then((res) => {
          dispatch(
            setTotalWorkedSecondsToday(res.tasks.totalWorkedSecondsToday)
          );
          return dispatch(setTasks({ tasks: res.tasks.response }));
        })
        .catch((err) => {
          console.log(err);
        });
    }

  }, [selectedCompany]);


  useEffect(()=> {
    if (selectedCompany?.companyId) {
      listUserTasks(selectedCompany.companyId)
        .then((res) => {
          dispatch(
            setTotalWorkedSecondsToday(res.tasks.totalWorkedSecondsToday)
          );
          return dispatch(syncTasks({ tasks: res.tasks.response }));
        })
        .catch((err) => {
          console.log(err);
        });
    }
  },[sync])

  useEffect(() => {
    if (selectedCompany?.companyId && refreshAfterIdle) {
      listUserTasks(selectedCompany.companyId)
        .then((res) => {
          dispatch(
            setTotalWorkedSecondsToday(res.tasks.totalWorkedSecondsToday)
          );
          dispatch(setRefreshAfterIdle(false));
          return dispatch(setTasks({ tasks: res.tasks.response }));
        })
        .catch((err) => {
          console.log(err);
        });
    }
  }, [selectedCompany, refreshAfterIdle]);

  const onSubmit = async (data: CreateTaskFormData) => {
    try {
      const response = await createTask(data, selectedCompany?.companyId);
      if (response) {
        dispatch(addTask(response));
        setValue('title', '');
      }
    } catch (err) {
      console.log(err);
    }
  };
// const handelUpdateingAppEvents = () =>{
//   console.log('START LISTEN TO UPDATE EVENTS');
//   handleAppUpdateEvents()
// };

  return (
    <div>

      {/* sync tasks added from web*/}
      <div className='flex items-center justify-end w-100'>
        <button onClick={()=> setSync(prev => !prev)}  className="inline-flex items-center h-8 px-4 m-2 mt-0 ml-0 text-sm text-indigo-100 transition-colors duration-150 bg-warning rounded-lg focus:shadow-outline hover:bg-warning-hover">
          <span>Sync Tasks</span>
        </button>
        {/* <button
            onClick={async () => {
              await handelUpdateingAppEvents();
            }}
           className="inline-flex items-center h-8 px-4 m-2 mt-0 ml-0 text-sm text-indigo-100 transition-colors duration-150 bg-success rounded-lg focus:shadow-outline hover:bg-success-hover">
          <span>chceck for update</span>
        </button> */}

      </div>

      <FormProvider {...methods}>
        <form
          className=" flex flex-col"
          onSubmit={handleSubmit(onSubmit)}
        >
          <TextInputField
            placeholder="Add an item"
            icon={FaPlusCircle}
            labelText=""
            errorMessage=""
            register={register('title')}
          />
        </form>
      </FormProvider>
      {tasks.length > 0
        ?
        <>
         <div className="mt-3 flex flex-row">✍ Planned tasks list</div>
                  {tasks?.map((task) => {
                    return task.status === TaskStatus.PLANNED ? (
                      <div key={task._id}>
                        <TaskRow task={task} />
                      </div>
                      ) : null;
                  })}

                  <div className="mt-3 flex flex-row">✨ Done !</div>

                  {tasks?.map((task) => {
                    return task.status === TaskStatus.DONE ? (
                      <div key={task._id}>
                        <TaskRow task={task} />
                      </div>
                    ) : null;
                  })}
        </>
        : (<b>No Tasks Added yet</b>)}
    </div>
  );
}
