/* eslint-disable jsx-a11y/anchor-is-valid */
import { yupResolver } from '@hookform/resolvers/yup';
import React, { useState } from 'react';
import { FormProvider, useForm } from 'react-hook-form';

import { useAppDispatch } from 'renderer/hooks/store.hook';
import { useNavigate } from 'react-router-dom';
import { SignInFormValidator } from 'renderer/resolvers/auth.validator';
import { SignInFormData } from 'types/auth.type';
import { Button } from 'flowbite-react';
import {
  openExternalLink,
  setElectronStore,
} from 'renderer/utils/electron-utils';
import { login } from 'api';
import {
  setSelectedCompany,
  setUser,
} from 'renderer/redux/features/user.slice';
import { AxiosError } from 'axios';
import EmailInputField from '../atoms/Inputs/EmailInputField';
import PasswordInputField from '../atoms/Inputs/PasswordInputField';
import ErrorText from '../atoms/Inputs/ErrorText';

export default function LoginTemplate() {
  const dispatch = useAppDispatch();
  const navigate = useNavigate();
  const [loginErr, setLoginErr] = useState<string>();

  const methods = useForm<SignInFormData>({
    mode: 'onSubmit',
    resolver: yupResolver(SignInFormValidator),
    defaultValues: {
      username: '',
      password: '',
    },
  });

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = methods;

  const onSubmit = (data: SignInFormData) => {
    login(data)
      .then((res) => {
        setElectronStore<string>('access_token', res.accessToken);
        dispatch(setUser(res.user));
        dispatch(setSelectedCompany(res.user.companies[0]));
        return navigate('/');
      })
      .catch((err: AxiosError) => {
        // TODO: global error handler
        console.log(err);
        if (err.response?.status === 401) {
          setLoginErr('Wrong credentials');
        } else {
          setLoginErr('Something went wrong, please try again later');
        }
      });
  };
  return (
    <div >
      {loginErr && <ErrorText errorMessage={loginErr} />}
      <FormProvider {...methods}>
        <form className="auth flex h-auto w-80 min-w-fit flex-col justify-center rounded-3xl bg-latte p-8" onSubmit={handleSubmit(onSubmit)}>
          <EmailInputField
            register={register('username')}
            labelText="Email"
            placeholder="example@domain.com"
            errorMessage={errors.username?.message}
          />
          <PasswordInputField
            register={register('password')}
            labelText="Password"
            errorMessage={errors.password?.message}
          />
          <Button type="submit"  className="relative mb-2 ml-16 mt-6 flex w-32 items-end justify-center bg-accent">Login</Button>
        </form>
      </FormProvider>
      <div className="flex justify-center">
        <a
          href="#"
          key="external_navigation"
          onClick={() => {
            // TODO: wrap links in constants
            openExternalLink('http://localhost:3000/auth/forget-password');
          }}
          className="text-primary-75 hover:text-blue-700 font-medium rounded cursor-pointer my-4"
        >
          Forgot Password?
        </a>
      </div>
    </div>
  );
}
