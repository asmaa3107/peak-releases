import React from 'react';
import { Sidebar } from 'flowbite-react';
import { AiTwotoneEdit } from 'react-icons/ai';
import { BsClockFill } from 'react-icons/bs';
import { openExternalLink } from 'renderer/utils/electron-utils';
import config from './../../../utils/config';
import { FaSignOutAlt } from 'react-icons/fa';
import { dispatch } from 'renderer/redux/store';
import { logOut } from 'renderer/redux/features/user.slice';
import { clearTasks } from 'renderer/redux/features/task.slice';
import { useNavigate } from "react-router-dom";

export default function ActionsSidebar() {
  const EDIT_LINK=config.peakFrontend+'edit-time';
  const REPORTS_LINK=config.peakFrontend+'hours-report';
  const navigate = useNavigate();

  const signOut =()=>{
    console.log('signnig out ...');
    //TODO : show modal if user traking task to confirm close task before logout
    // dispatch(setSwitchCompanyWarningModal(true));
    dispatch(logOut());
    dispatch(clearTasks());
    navigate("/login");
  }

  return (
    <Sidebar className="menu-nav">
      <div className="bg-gray-200  h-full">
        <Sidebar.Items>
          <Sidebar.ItemGroup>
            <Sidebar.Item
              href="#"
              className="hover:border-none "
              icon={AiTwotoneEdit}
              onClick={() => openExternalLink(EDIT_LINK)}
            >
              Edit Time
            </Sidebar.Item>
            <Sidebar.Item
              href="#"
              className="hover:border-none "
              icon={BsClockFill}
              onClick={() => openExternalLink(REPORTS_LINK)}
            >
              Hours Report
            </Sidebar.Item>
            <Sidebar.Item
              href="#"
              className="hover:border-none "
              icon={FaSignOutAlt}
              onClick={signOut}
            >
              Sign Out
            </Sidebar.Item>
          </Sidebar.ItemGroup>
        </Sidebar.Items>
      </div>
    </Sidebar>
  );
}
