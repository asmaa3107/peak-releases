import React from 'react';
import IdleWarningModal from '../molecules/Modals/IdleWarningModal';
import IdleModal from '../molecules/Modals/IdleModal';
import SwitchCompanyWarningModal from '../molecules/Modals/SwitchCompanyWarningModal';

export default function ModalsTemplate() {
  return (
    <> 
      <IdleWarningModal />
      <IdleModal />
      <SwitchCompanyWarningModal />
    </>
  );
}
