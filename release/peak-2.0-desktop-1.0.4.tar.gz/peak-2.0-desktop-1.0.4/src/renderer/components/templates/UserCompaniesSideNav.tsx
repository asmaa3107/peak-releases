import React, { useState } from 'react';
import { useAppDispatch, useAppSelector } from 'renderer/hooks/store.hook';
import { Avatar, Sidebar, Tooltip } from 'flowbite-react';
import { UserCompany } from 'types';
import {
  setDesiredSelectedCompany,
  setSelectedCompany,
} from 'renderer/redux/features/user.slice';
import { resetTimeTrackerState } from 'renderer/redux/features/timeTracker.slice';
import { setSwitchCompanyWarningModal } from 'renderer/redux/features/modal.slice';
import ActionsSidebar from './ActionsSideNav';

export default function UserCompaniesSidebar() {
  const dispatch: any = useAppDispatch();

  const {
    userState,
    timeTrackerState: { isTracking },
  } = useAppSelector((state) => state);
  const userCompanies = userState.user?.companies;

  const { selectedCompany } = userState;

  const isSelectedCompany = (company: UserCompany) =>
    company === selectedCompany;

  const isSelectedCompanyStyle = (company: UserCompany) =>
    isSelectedCompany(company) ? 'comp-avatar selected' : 'comp-avatar';

  const handleCompanySelect = (company: UserCompany) => {
    if (selectedCompany !== company) {
      if (isTracking) {
        dispatch(setDesiredSelectedCompany(company));
        dispatch(setSwitchCompanyWarningModal(true));
        return;
      }
      dispatch(setSelectedCompany(company));
      dispatch(resetTimeTrackerState());
    } else {
      return;
    }
  };
  const [isShowing, setIsShowing] = useState(false);

  return (
    <>
      <div className=" subSide h-full scroll-auto fixed z-40">
        <Sidebar className="p-0 m-0 sideNav w-fit">
          <Sidebar.Items className="sideItem">
            <Sidebar.ItemGroup>
              <Sidebar.Item
                href="#"
                className="bg-transparent hover:bg-gray-500 text-white "
                onClick={() => setIsShowing((isShowing) => !isShowing)}
              >
                <svg
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  viewBox="0 0 24 24"
                  xmlns="http://www.w3.org/2000/svg"
                  aria-hidden="true"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"
                  ></path>
                </svg>
              </Sidebar.Item>
              {userCompanies &&
                userCompanies.map((company) => (
                  <Sidebar.Item
                    href="#"
                    key={company.companyId}
                    className="hover:bg-gray-500 bg-primary sub-item w-fit"
                  >
                    <Tooltip content={company.companyName} style="dark">
                      <Avatar
                        rounded={false}
                        bordered={true}
                        color="white"
                        placeholderInitials={company.companyName
                          .slice(0, 2)
                          .toUpperCase()}
                        onClick={() => handleCompanySelect(company)}
                        className={`${isSelectedCompanyStyle(company)}`}
                      />
                    </Tooltip>
                  </Sidebar.Item>
                ))}
            </Sidebar.ItemGroup>
          </Sidebar.Items>
        </Sidebar>
      </div>

      <div
        className={
          isShowing
            ? 'transition-all bg-white delay-200 ml-16 '
            : 'transition-all bg-white delay-200 -ml-48'
        }
      >
        <ActionsSidebar />
      </div>
    </>
  );
}
