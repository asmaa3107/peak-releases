import React from 'react';
import {
  useTimerCounterInterval,
  useTimerRefreshPoll,
} from 'renderer/hooks/timer.hook';

export default function HomeLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  useTimerRefreshPoll();
  useTimerCounterInterval();
  return <div className="flex w-full h-[100vh]">{children}</div>;
}
