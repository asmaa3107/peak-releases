import React from 'react';
import LoginImage from '../../../../../assets/svg/login.svg';

export default function LoginLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="container-fluid mx-auto flex h-full flex-col-reverse space-y-0 px-0 md:flex-row md:space-y-0">
      {/* left section [form] */}
      <div className="flex justify-center h-full bg-white p-32 md:w-1/2 ">
        <div>{children}</div>
      </div>
    </div>
  );
}
