import React from 'react';

import UserTasks from '../organisms/UserTasks';
import HeadTimer from '../molecules/Timers/HeadTimer';

export default function HomeTemplate() {
  return (
    <div className="app-body">
      <HeadTimer />
      <div className="mx-4">
        <UserTasks />
      </div>
    </div>
  );
}
