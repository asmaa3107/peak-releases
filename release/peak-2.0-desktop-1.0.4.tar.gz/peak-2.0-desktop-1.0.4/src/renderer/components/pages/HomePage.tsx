import useAuthGuard from 'renderer/hooks/auth.hook';
import HomeLayout from '../templates/Layouts/HomeLayout';
import UserCompaniesSidebar from '../templates/UserCompaniesSideNav';
import HomeTemplate from '../templates/HomeTemplate';
import ModalsTemplate from '../templates/ModalsTemplat';

export default function Home() {
  useAuthGuard();
  return (
    <HomeLayout>
      <UserCompaniesSidebar />
      <HomeTemplate />
      <ModalsTemplate />
    </HomeLayout>
  );
}
