import LoginLayout from '../templates/Layouts/LoginLayout';
import LoginTemplate from '../templates/LoginTemplate';

export default function LoginPage() {
  return (
    <LoginLayout>
      <LoginTemplate />
    </LoginLayout>
  );
}
