/* eslint-disable no-underscore-dangle */
/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-vars */
import type { PayloadAction } from '@reduxjs/toolkit';
import { createSlice } from '@reduxjs/toolkit';
import { TimeTrackerState } from 'types/task-tracking.type';

const initialState: TimeTrackerState = {
  trackingId: '',
  taskTitle: '',
  isTracking: false,
  idleTimeoutInSeconds: 0,
  taskId: '',
  currentTaskTodayWorkedSeconds: 0,
  totalWorkedSecondsToday: 0,
  refreshAfterIdle: false,
};

const taskTrackerSlice = createSlice({
  name: 'taskTracking',
  initialState,
  reducers: {
    setCurrentTaskTrackingState: (
      state,
      action: PayloadAction<TimeTrackerState>
    ) => {
      const {
        currentTaskTodayWorkedSeconds,
        idleTimeoutInSeconds,
        isTracking,
        taskId,
        taskTitle,
        trackingId,
      } = action.payload;
      state.currentTaskTodayWorkedSeconds = currentTaskTodayWorkedSeconds;
      state.idleTimeoutInSeconds = idleTimeoutInSeconds;
      state.taskId = taskId;
      state.taskTitle = taskTitle;
      state.isTracking = isTracking;
      state.trackingId = trackingId;
    },
    incrementCurrentTaskTodayWorkedSeconds: (state) => {
      state.currentTaskTodayWorkedSeconds += 1;
    },
    incrementTotalWorkedSecondsToday: (state) => {
      state.totalWorkedSecondsToday += 1;
    },
    setIsTrackingState: (state, action: PayloadAction<boolean>) => {
      state.isTracking = action.payload;
    },
    setTotalWorkedSecondsToday: (state, action: PayloadAction<number>) => {
      state.totalWorkedSecondsToday = action.payload;
    },
    setRefreshAfterIdle: (state, action: PayloadAction<boolean>) => {
      state.refreshAfterIdle = action.payload;
    },
    resetTimeTrackerState: (state) => {
      state.trackingId = '';
      state.taskTitle = '';
      state.isTracking = false;
      state.idleTimeoutInSeconds = 0;
      state.taskId = '';
      state.currentTaskTodayWorkedSeconds = 0;
      state.totalWorkedSecondsToday = 0;
    },
    resetHeaderTimeTrackerState: (state) => {
      state.trackingId = '';
      state.taskTitle = '';
      state.isTracking = false;
      state.idleTimeoutInSeconds = 0;
      state.taskId = '';
    },
  },
});

export default taskTrackerSlice.reducer;
export const {
  incrementCurrentTaskTodayWorkedSeconds,
  incrementTotalWorkedSecondsToday,
  setCurrentTaskTrackingState,
  setIsTrackingState,
  setTotalWorkedSecondsToday,
  resetTimeTrackerState,
  resetHeaderTimeTrackerState,
  setRefreshAfterIdle
} = taskTrackerSlice.actions;
