import { PayloadAction, createSlice } from '@reduxjs/toolkit';
import { getElectronStore, setElectronStore } from 'renderer/utils/electron-utils';
import { UserCompany } from 'types';
import { User, UserState } from 'types/user.type';

const initialState: UserState = {
  user: null,
  selectedCompany: null,
  desiredSelectedCompany: null,
};
let accessToken = getElectronStore<string>('access_token');

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    setUser(state, action: PayloadAction<User>) {
      state.user = action.payload;
    },
    setSelectedCompany(state, action: PayloadAction<UserCompany>) {
      state.selectedCompany = action.payload;
    },
    setDesiredSelectedCompany(state, action: PayloadAction<UserCompany>) {
      state.desiredSelectedCompany = action.payload;
    },
    logOut: (state) => {
      state.user = null;
      setElectronStore<String>('access_token','')
      state.selectedCompany = null;
    },
  },
});

export const { setUser, setSelectedCompany, setDesiredSelectedCompany,logOut } =
  userSlice.actions;
export default userSlice.reducer;
