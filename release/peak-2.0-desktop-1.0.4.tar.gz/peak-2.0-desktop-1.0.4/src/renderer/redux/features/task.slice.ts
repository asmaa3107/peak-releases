/* eslint-disable no-underscore-dangle */
/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-vars */
import type { PayloadAction } from '@reduxjs/toolkit';
import { createSlice } from '@reduxjs/toolkit';
import { TimeTrackerState } from 'types/task-tracking.type';
import {
  CreateTaskResponse,
  DeleteTaskResponse,
  Task,
  TasksState,
} from 'types/task.types';

const initialState: TasksState = {
  tasks: [],
};

const tasksSlice = createSlice({
  name: 'tasks',
  initialState,
  reducers: {
    editTask: (state, action: PayloadAction<DeleteTaskResponse>) => {
      const { task } = action.payload;
      const taskIndex = state.tasks.findIndex(
        (findTask) => findTask._id === task._id
      );
      state.tasks.splice(taskIndex, 1, task);
    },
    deleteTask: (state, action: PayloadAction<DeleteTaskResponse>) => {
      const taskIndex = state.tasks.findIndex(
        (findTask) => findTask._id === action.payload.task._id
      );
      state.tasks.splice(taskIndex, 1);
    },
    addTask: (state, action: PayloadAction<CreateTaskResponse>) => {
      state.tasks.push({ ...action.payload.task, totalWorkedSecondsToday: 0 });
    },
    setTasks: (state, action: PayloadAction<{ tasks: Task[] }>) => {
      state.tasks = action.payload.tasks;
    },
    syncTasks: (state, action: PayloadAction<{ tasks: Task[] }>) => {
      const filteredTasks :Task[]= [];
      action.payload.tasks.forEach((element : Task) => {

        if (!state.tasks.find((task: Task) => task._id === element._id)) {
          filteredTasks.push(element);
        }
      });

      state.tasks.push(...filteredTasks);
    },
    incrementTaskTotalWorkedSecondsToday: (
      state,
      action: PayloadAction<{ taskId: string }>
    ) => {
      const { taskId } = action.payload;
      const task = state.tasks.find((t) => t._id === taskId);
      if (task) {
        task.totalWorkedSecondsToday += 1;
      }
    },
    clearTasks: (state) => {
      state.tasks = [];
    },
  },
});

export default tasksSlice.reducer;
export const {
  setTasks,
  syncTasks,
  incrementTaskTotalWorkedSecondsToday,clearTasks,
  addTask,
  deleteTask,
  editTask,
} = tasksSlice.actions;
