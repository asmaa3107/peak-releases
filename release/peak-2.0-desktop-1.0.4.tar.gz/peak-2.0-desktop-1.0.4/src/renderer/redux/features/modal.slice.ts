/* eslint-disable no-underscore-dangle */
/* eslint-disable no-param-reassign */
/* eslint-disable no-unused-vars */
import type { PayloadAction } from '@reduxjs/toolkit';
import { createSlice } from '@reduxjs/toolkit';
import { ModalState } from 'types/modal.type';

const initialState: ModalState = {
  showIdleWarningModal: false,
  showIdleModal: false,
  showSwitchCompanyWarningModal: false,
};

const modalSlice = createSlice({
  name: 'modal',
  initialState,
  reducers: {
    setShowIdleWarningModal: (state, action: PayloadAction<boolean>) => {
      state.showIdleWarningModal = action.payload;
    },
    setShowIdleModal: (state, action: PayloadAction<boolean>) => {
      state.showIdleModal = action.payload;
    },
    setSwitchCompanyWarningModal: (state, action: PayloadAction<boolean>) => {
      state.showSwitchCompanyWarningModal = action.payload;
    },
  },
});

export default modalSlice.reducer;
export const {
  setShowIdleWarningModal,
  setShowIdleModal,
  setSwitchCompanyWarningModal,
} = modalSlice.actions;
