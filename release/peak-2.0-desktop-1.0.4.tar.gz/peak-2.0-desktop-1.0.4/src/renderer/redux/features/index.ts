import { combineReducers } from 'redux';

import userReducer from './user.slice';
import taskTrackerReducer from './timeTracker.slice';
import tasksReducer from './task.slice';
import modalReducer from './modal.slice';

const rootReducer = combineReducers({
  // Define your reducers here
  userState: userReducer,
  timeTrackerState: taskTrackerReducer,
  tasksState: tasksReducer,
  modalState: modalReducer,
});

export default rootReducer;
