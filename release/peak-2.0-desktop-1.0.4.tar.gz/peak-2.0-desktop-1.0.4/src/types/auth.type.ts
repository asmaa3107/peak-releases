import { User } from './user.type';

export type SignInFormData = {
  username: string;
  password: string;
};

export type SignInResponseData = {
  user: User;
  accessToken: string;
};

export type GetUserInfoResponse = User;
