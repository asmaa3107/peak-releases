export type ModalState = {
  showIdleWarningModal: boolean;
  showIdleModal: boolean;
  showSwitchCompanyWarningModal: boolean;
};
