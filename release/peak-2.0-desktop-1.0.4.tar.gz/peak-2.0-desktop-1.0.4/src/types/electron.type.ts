/* eslint-disable no-unused-vars */
/* eslint-disable no-shadow */
/* eslint-disable import/prefer-default-export */

export enum Channels {
  IPC_EXAMPLE = 'ipc-example',
  OPEN_EXTERNAL_LINK = 'open-external-link',
  ELECTRON_STORE_GET = 'electron-store-get',
  ELECTRON_STORE_SET = 'electron-store-set',
  TIME_TRACKING_STARTED = 'time-tracking-started',
  TIME_TRACKING_STOPPED = 'time-tracking-stopped',
  SHOW_IDLE_WARNING_MODAL = 'show-idle-modal',
  IDLE_DETECTED = 'idle-detected',
  APP_QUIT = 'app-quit',
  //-----Releae Updater----------------
  UPDATE_AVAILABLE = 'update-available',
  UPDATE_NOT_AVAILABLE = 'update-not-available',
  UPDATE_CANCELLED = 'update-cancelled',
  UPDATE_DOWNLOADED = 'update-downloaded',
}
