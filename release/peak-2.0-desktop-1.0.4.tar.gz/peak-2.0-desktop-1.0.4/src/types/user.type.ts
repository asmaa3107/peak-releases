/* eslint-disable no-unused-vars */
/* eslint-disable no-shadow */

import { UserCompany } from './company.type';

export enum UserStatus {
  COMPLETED = 'Completed',
  REQUIRE_FULL_SIGNUP = 'Require_Full_Signup',
  Deactivated = 'Deactivated',
}

export type User = {
  _id: string;
  name: string;
  email: string;
  status: UserStatus;
  companies: UserCompany[];
  createdAt: string;
  updatedAt: string;
};

export type UserState = {
  user: User | null;
  selectedCompany: UserCompany | null;
  desiredSelectedCompany: UserCompany | null;
};
