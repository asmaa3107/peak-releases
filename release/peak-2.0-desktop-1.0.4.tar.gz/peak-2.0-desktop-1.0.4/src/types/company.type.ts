/* eslint-disable no-shadow */
/* eslint-disable no-unused-vars */

export type Company = {
  _id: string;
  name: string;
  createdAt: string;
  updatedAt: string;
  totalHours: number;
  timezone: string;
};

export enum UserCompanyRole {
  OWNER = 'Owner',
  ADMIN = 'Admin',
  MANAGER = 'Manager',
  REGULAR_USER = 'Regular_User',
}

export enum UserCompanyTrackingType {
  WEB = 'Web',
  DESKTOP = 'Desktop',
  BOTH = 'Both',
}

export enum UserCompanyStatus {
  ACTIVE = 'Active',
  PENDING = 'Pending',
  INACTIVE = 'Inactive',
}

export type UserCompany = {
  companyId: string;
  role: UserCompanyRole;
  companyName: string;
  createdAt: string;
  updatedAt: string;
  status: UserCompanyStatus;
  allowedIdleTime: number;
  takeScreenshot: boolean;
  editTime: boolean;
  trackingType: UserCompanyTrackingType;
};
