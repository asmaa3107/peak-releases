/* eslint-disable no-unused-vars */
/* eslint-disable no-shadow */

export enum TaskStatus {
  PLANNED = 'Planned',
  DONE = 'Done',
  DRAFT = 'Draft',
}

export type Task = {
  _id: string;
  title: string;
  companyId: string;
  userId: string;
  status: TaskStatus;
  isPublished: boolean;
  totalWorkedSecondsToday: number;
  updatedAt: Date;
  createdAt: Date;
};

export type TasksState = {
  tasks: Task[];
};

export type ListTasksResponse = {
  tasks: {
    response: Task[];
    totalWorkedSecondsToday: number;
  };
};
export type CreateTaskFormData = {
  title: string;
};

export type CreateTaskResponse = {
  task: Task;
};

export type DeleteTaskResponse = {
  task: Task;
};

export type UpdateTaskFormData = {
  title?: string;
  status?: TaskStatus;
  _id: string;
};

export type UpdateTaskResponse = {
  task: Task;
};
