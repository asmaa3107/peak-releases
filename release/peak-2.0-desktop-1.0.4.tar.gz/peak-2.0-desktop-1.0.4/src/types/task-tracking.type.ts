export type TimeTrackerState = {
  trackingId: string;
  taskId: string;
  taskTitle: string;
  isTracking: boolean;
  currentTaskTodayWorkedSeconds: number;
  idleTimeoutInSeconds: number;
  totalWorkedSecondsToday: number;
  refreshAfterIdle?: boolean;
};

export type TaskTrackingSession = {
  trackingId: string;
  taskId: string;
  idleTimeout: number;
  totalWorkedSecondsToday: number;
};

export type InitiateTrackingSessionResponse = TaskTrackingSession;
