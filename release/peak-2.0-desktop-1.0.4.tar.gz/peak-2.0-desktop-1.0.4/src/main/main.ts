/* eslint global-require: off, no-console: off, promise/always-return: off */

/**
 * This module executes inside of electron's main process. You can start
 * electron renderer process from here and communicate with the other processes
 * through IPC.
 *
 * When running `npm run build` or `npm run build:main`, this file is compiled to
 * `./src/main.js` using webpack. This gives us some performance wins.
 */
import path from 'path';
import { app, BrowserWindow, shell, ipcMain, dialog } from 'electron';
import { autoUpdater} from 'electron-updater';
import log from 'electron-log';
import MenuBuilder from './menu';
import { resolveHtmlPath } from './util';
import logger from 'electron-log'
import { handleEvents } from './handlers';

class AppUpdater {
  constructor() {
    log.transports.file.level = 'info';
    autoUpdater.logger = log;
    autoUpdater.checkForUpdatesAndNotify();
  }
}
// autoUpdater.autoDownload = true;
// autoUpdater.autoInstallOnAppQuit = true;

// const updateFeedUrl =autoUpdater.setFeedURL({
//   provider: 'github',
//   repo: 'peak-2.0-desktop',
//   releaseType: 'release',
//   token:process.env.GH_TOKEN,
//   owner:'anthibo',
//   private:true,
//   host: 'github.com',
//   channel: 'latest',

// });
const updateFeedURL =autoUpdater.setFeedURL('https://github.com/anthibo/peak-2.0-desktop/releases');
let mainWindow: BrowserWindow | null = null;

app.on('ready', () => {
  // Define the options for the message box

});
// ipc events handler
ipcMain.on('ipc-example', async (event, arg) => {
  const msgTemplate = (pingPong: string) => `IPC test: ${pingPong}`;
  console.log(msgTemplate(arg));
  logger.info(msgTemplate(arg));
  //reply to front renderer message
  event.reply('ipc-example', msgTemplate('pong'));
});

handleEvents();

// checking for env
if (process.env.NODE_ENV === 'production') {
  const sourceMapSupport = require('source-map-support');
  sourceMapSupport.install();
}

const isDebug =
  process.env.NODE_ENV === 'development' || process.env.DEBUG_PROD === 'true';

if (isDebug) {
  require('electron-debug')();
}


// install extensions
const installExtensions = async () => {
  const installer = require('electron-devtools-installer');
  const forceDownload = !!process.env.UPGRADE_EXTENSIONS;
  const extensions = ['REACT_DEVELOPER_TOOLS'];

  return installer
    .default(
      extensions.map((name) => installer[name]),
      forceDownload
    )
    .catch(console.log);
};

// rendering window
const createWindow = async () => {
  if (isDebug) {
    await installExtensions();
  }

  const RESOURCES_PATH = app.isPackaged
    ? path.join(process.resourcesPath, 'assets')
    : path.join(__dirname, '../../assets');

  const getAssetPath = (...paths: string[]): string => {
    return path.join(RESOURCES_PATH, ...paths);
  };

  mainWindow = new BrowserWindow({
    show: false,
    width: 768,
    height: 728,
    // maxWidth: 800,
    // minWidth: 650,
    icon: getAssetPath('icon.png'),
    webPreferences: {
      preload: app.isPackaged
        ? path.join(__dirname, 'preload.js')
        : path.join(__dirname, '../../.erb/dll/preload.js'),
    },
  });

  mainWindow.loadURL(resolveHtmlPath('index.html'));

  mainWindow.on('ready-to-show', () => {
    if (!mainWindow) {
      throw new Error('"mainWindow" is not defined');
    }


    if (process.env.START_MINIMIZED) {
      mainWindow.minimize();
    } else {
      mainWindow.show();
    }
  });

  mainWindow.on('closed', () => {
    mainWindow = null;
  });

  const menuBuilder = new MenuBuilder(mainWindow);
  menuBuilder.buildMenu();

  // Open urls in the user's browser
  mainWindow.webContents.setWindowOpenHandler((edata) => {
    shell.openExternal(edata.url);
    return { action: 'deny' };
  });

};
// rendering window
export const popupWindow = async () => {
  if (!mainWindow) {
    throw new Error('"mainWindow" is not defined');
  } else {
    // mainWindow.show();
    mainWindow.moveTop();
    mainWindow.focus();
    mainWindow.minimize();
    mainWindow.restore();
    app.focus({ steal: true });
  }
};
/**
 * Add event listeners...
 */

app.on('window-all-closed', () => {
  // Respect the OSX convention of having the application in memory even
  // after all windows have been closed
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

//Global exception handler
process.on("uncaughtException", function (err) {
  console.log(err);
});
function isDev() {
  return !app.isPackaged;
};
app.whenReady().then(() => {
    logger.info(`tokkkkken ${process.env.GH_TOKEN}`);
    logger.info(`test url ${updateFeedURL}`);
    logger.info(`test url ${autoUpdater.getFeedURL()}`);
    autoUpdater.checkForUpdates();
    createWindow();
  });

app.on('activate', () => {
  // Define the options for the message box
  // On macOS it's common to re-create a window in the app when the
  // dock icon is clicked and there are no other windows open.
  if (mainWindow === null) createWindow();
});

//=====================================================

autoUpdater.autoDownload = true;
autoUpdater.autoInstallOnAppQuit = true;
autoUpdater.forceDevUpdateConfig = true;

logger.info(`env mode : ${process.env.NODE_ENV}`);
autoUpdater.on('error', (err) => {
  autoUpdater.logger?.error(`Error checking for updates ===> ${err}` );
  logger.info(`Update downloaded ===>  ${err}`);

});

autoUpdater.on('update-downloaded', (info) => {
  logger.info(`Update downloaded ===>  ${info}`);
});




app.on('ready', () => {
  //UPDATE EVENTS
   if (autoUpdater.forceDevUpdateConfig) {
    console.log('forceeee');
    console.log(autoUpdater.forceDevUpdateConfig);
    logger?.info(`Current update feed URL:===>  ${updateFeedURL}`);

    console.log(`Current update feed URL: ${updateFeedURL}`);
    autoUpdater.checkForUpdates().then((updateResult) => {
      logger.info(`Auto-update check completed ======> ${updateResult}`)
        console.log('Auto-update check completed');
        if (updateResult !== null) {
        const dialogOpts = {
        type: 'info',
        buttons: ['Update', 'Later'],
        title: 'Update Available',
        message: `A new version of ${app.getName()} is available. Do you want to update now?`,
        detail: `Version number is now available. It will be downloaded in the background and installed on restart.`,
        };
        dialog.showMessageBox(dialogOpts).then((returnValue) => {
          console.log('showen')
          console.log(returnValue)
           logger?.info(`Current update feed URL:===>  ${returnValue}`);

        if (returnValue.response === 0) {
              autoUpdater.downloadUpdate().then(()=>{
                console.log('updateing...')
                 logger?.info(`updateing ...`);

                autoUpdater.quitAndInstall()
              });
            }
            else if(returnValue.response === 1){
              console.log('later')
              logger?.info(`later ...`);
            }

            }).catch(err => console.log(err))
            } else {
              autoUpdater.on('update-not-available', () => {
                console.log('not avaliable');
                logger?.info(`not avaliable !! ...`);

                dialog.showMessageBox({
                  message: 'No updates available',
                  buttons: ['OK'],
                  type: 'info',
                });
              });
            logger?.info(`No updates available`);
            console.log('No updates available');
            }
            });
        } else {
          logger?.info('Auto-update check skipped: app is not packed or dev update config is not forced');
          console.log('Auto-update check skipped: app is not packed or dev update config is not forced');
        }
});
