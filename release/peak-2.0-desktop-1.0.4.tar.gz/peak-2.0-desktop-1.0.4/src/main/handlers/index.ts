/* eslint-disable import/prefer-default-export */
import { handleElectronStoreEvents } from './electron-store.handler';
import { handleIdleDetection } from './idle-detection.handler';
import { handleOnBeforeClose, handleOpenExternalEvent } from './utils.handler';

export const handleEvents = () => {
  handleOnBeforeClose();
  handleOpenExternalEvent();
  handleElectronStoreEvents();
  handleIdleDetection();
};
