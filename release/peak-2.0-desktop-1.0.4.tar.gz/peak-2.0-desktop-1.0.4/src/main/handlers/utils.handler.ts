/* eslint-disable import/prefer-default-export */
import { app, ipcMain, shell } from 'electron';
import { Channels } from '../../types/electron.type';

const handleOpenExternalEvent = () => {
  ipcMain.on(Channels.OPEN_EXTERNAL_LINK, async (event, arg) => {
    const [url] = arg;
    await shell.openExternal(url);
  });
};
const handleOnBeforeClose = () => {
  ipcMain.on(Channels.APP_QUIT, () => {
    app.quit();
  });
};
export { handleOpenExternalEvent, handleOnBeforeClose };
