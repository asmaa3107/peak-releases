/* eslint-disable no-undef */
/* eslint-disable import/prefer-default-export */
import { ipcMain, powerMonitor } from 'electron';
import { Channels } from '../../types/electron.type';
import { popupWindow } from '../main';

export const handleIdleDetection = () => {
  let idleInterval: NodeJS.Timeout;
  let idleWarningEventSent = false;
  let idleWarningState = false;
  ipcMain.on(
    Channels.TIME_TRACKING_STARTED,
    async (event, idleThresholdSeconds: number) => {
      idleWarningEventSent = false;
      if(idleWarningState){
        clearInterval(idleInterval);
        idleWarningState = false;
      }
      console.log('TIME_TRACKING_STARTED event detected');
      let timeRemaining = idleThresholdSeconds;
      idleInterval = setInterval(() => {
        const systemIdleTimeInSeconds = powerMonitor.getSystemIdleTime();
        timeRemaining = idleThresholdSeconds - systemIdleTimeInSeconds;
         console.log(`time remaining to idle :${timeRemaining}`);
        // if (timeRemaining < 11 && !idleWarningEventSent) {
        //   console.log('Emit SHOW_IDLE_WARNING_MODAL event');
        //   event.reply(Channels.SHOW_IDLE_WARNING_MODAL);
        //   idleWarningEventSent = true;
        //   idleWarningState= true;
        //   popupWindow();
        // }

        if (timeRemaining <= 1) {
          console.log('User is IDLE');
          //  console.log('EMIT IDLE_DETECTED event');
          //  event.reply(Channels.IDLE_DETECTED);
          console.log('====================');
          console.log(timeRemaining);
          popupWindow();
          console.log('Emit SHOW_IDLE_WARNING_MODAL event');
          event.reply(Channels.SHOW_IDLE_WARNING_MODAL);
          idleWarningEventSent = true;
          idleWarningState= true;
          clearInterval(idleInterval);

        }
      }, 1000);
    }
  );
  ipcMain.on(Channels.TIME_TRACKING_STOPPED, async () => {
    console.log('Received TIME_TRACKING_STOPPED event');
    clearInterval(idleInterval);
  });
};
