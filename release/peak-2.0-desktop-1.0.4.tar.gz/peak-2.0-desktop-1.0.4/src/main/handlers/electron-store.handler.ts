/* eslint-disable import/prefer-default-export */

import { ipcMain } from 'electron';
import Store from 'electron-store';
import { Channels } from '../../types';

const store = new Store();

export const handleElectronStoreEvents = () => {
  ipcMain.on(Channels.ELECTRON_STORE_GET, async (event, val) => {
    event.returnValue = store.get(val);
  });
  ipcMain.on(Channels.ELECTRON_STORE_SET, async (_event, key, val) => {
    store.set(key, val);
  });
};
